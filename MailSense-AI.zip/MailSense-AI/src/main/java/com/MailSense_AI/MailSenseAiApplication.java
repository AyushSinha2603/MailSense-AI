package com.MailSense_AI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailSenseAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailSenseAiApplication.class, args);
	}

}
